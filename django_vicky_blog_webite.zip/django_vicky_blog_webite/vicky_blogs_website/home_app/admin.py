from django.contrib import admin


# Register your models here.
from home_app.models import Contact
admin.site.register(Contact)